<?php
use escoli\Aplicacion;

$app = Aplicacion::getInstance();
?>

<aside id="sidebarDer">
	<?= $params['contenidoSideBarDer'] ?>
</aside>