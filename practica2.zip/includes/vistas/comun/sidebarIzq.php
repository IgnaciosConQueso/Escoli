<?php
use escoli\Aplicacion;

$app = Aplicacion::getInstance();
?>

<aside id="sidebarIzq">
	<?= $params['contenidoSideBarIzq'] ?>
</aside>